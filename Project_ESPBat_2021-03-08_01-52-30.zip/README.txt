DIY Bat recorder based on an ESP32

Github link :
[https://github.com/dbrouste/ESPBAT/wiki](https://github.com/dbrouste/ESPBAT/wiki)


Simulation results ([https://github.com/dbrouste/ESPBAT/tree/main/TinaTi%20Simulation])
Amp 52dB 15kHz to 280kHz
Noise S/N 97dB(30kHz), 82dB(100kHz), 75dB(250kHz)
THD 0.003436%(50Hz)

DAC 16-bit, 500-kSPS            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。